use db_salitre_magico;
DELETE FROM rol_usuario WHERE id_usuario >= 0;

DELETE FROM usuario WHERE id_usuario >= 0;

DELETE FROM empleado WHERE id_empleado >= 0;

INSERT INTO empleado
(`nombre`, `tipo_identificacion`,`identificacion`,`telefono`,`email`,`edad`)
VALUES
("admin",
"1",
"1234567890",
"3002334556",
"admin@salitre.com",
35);

SELECT id_empleado INTO @admin FROM empleado WHERE identificacion = "1234567890" limit 1;
-- metodo de encriptación y desencriptacion AES_ENCRYPT y AES_DECRYPT

INSERT INTO db_salitre_magico.usuario (usuario, password, id_empleado)
VALUES ('admin',AES_ENCRYPT('admin123','salitre'),@admin);


SELECT id_usuario INTO @usuario FROM usuario WHERE usuario = "admin" limit 1;
INSERT INTO `db_salitre_magico`.`rol_usuario`
(`tipo_empleado`,`id_usuario`,`estado`)
VALUES
(1,@usuario,1);

--  logistica

INSERT INTO empleado
(`nombre`, `tipo_identificacion`,`identificacion`,`telefono`,`email`,`edad`)
VALUES
("Arnold","1","12345","355555555","logistica@salitre.com",20);

SELECT id_empleado INTO @logistica FROM empleado WHERE identificacion = "12345" limit 1;
-- metodo de encriptación y desencriptacion AES_ENCRYPT y AES_DECRYPT

INSERT INTO db_salitre_magico.usuario (usuario, password, id_empleado)
VALUES ('logistica1',AES_ENCRYPT('logistica1','salitre'),@logistica);


SELECT id_usuario INTO @usuario2 FROM usuario WHERE usuario = "logistica1" limit 1;
INSERT INTO `db_salitre_magico`.`rol_usuario`
(`tipo_empleado`,`id_usuario`,`estado`)
VALUES
(2,@usuario2,1);




-- operario

INSERT INTO empleado
(`nombre`, `tipo_identificacion`,`identificacion`,`telefono`,`email`,`edad`)
VALUES
("Raul","1","0987654321","3204454455","operario@salitre.com",29);

SELECT id_empleado INTO @operario FROM empleado WHERE identificacion = "0987654321" limit 1;
-- metodo de encriptación y desencriptacion AES_ENCRYPT y AES_DECRYPT

INSERT INTO db_salitre_magico.usuario (usuario, password, id_empleado)
VALUES ('operario1',AES_ENCRYPT('operario1','salitre'),@operario);


SELECT id_usuario INTO @usuario3 FROM usuario WHERE usuario = "operario1" limit 1;
INSERT INTO `db_salitre_magico`.`rol_usuario`
(`tipo_empleado`,`id_usuario`,`estado`)
VALUES
(4,@usuario3,1);