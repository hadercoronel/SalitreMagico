SELECT * FROM empleado;
select * from usuario;
SELECT tipo_empleado FROM usuario, rol_usuario where usuario = "admin";
select * from rol_usuario;
select * from cliente;
SELECT tipo_empleado FROM usuario, rol_usuario where usuario = "admin";

SELECT e.id_empleado, e.nombre FROM usuario u, empleado e where u.usuario = "admin" AND u.id_empleado = e.id_empleado;
SELECT e.id_empleado, e.nombre, u.usuario FROM usuario u, empleado e where u.usuario = "logistica1" AND u.id_empleado = e.id_empleado;
SELECT e.id_empleado, e.nombre, u.usuario FROM usuario u, empleado e where u.usuario = "operario1" AND u.id_empleado = e.id_empleado;

SELECT *FROM `db_salitre_magico`.`pasaporte`;
