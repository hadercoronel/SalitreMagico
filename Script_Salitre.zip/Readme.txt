1- lo primero que hay que hacer es correr el script llamado:

"script_db_salitre_magico"

esto para que se cree la base de datos.

2- proxima mente debe ejecutarse el script llamado: 

"query"

esto creara los usuarios para que se pueda loguear en el sistema.

tiene 3 usuarios en script "admin", "logistica1", "operario1"

3- y por ultimo esta el script llamado:

"script_select"

este contiene select para visualizar datos en las tablas.